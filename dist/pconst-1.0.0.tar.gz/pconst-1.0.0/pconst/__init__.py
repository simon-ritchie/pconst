# coding: UTF-8

from pconst.const import Const
const = Const()
